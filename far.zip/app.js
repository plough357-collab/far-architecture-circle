const entryScreen = document.getElementById('entryScreen');
const navHomeBtn = document.getElementById('navHomeBtn');
const brandHome = document.getElementById('brandHome');
const sections = document.querySelectorAll('.content-section');

function showEntry() {
  entryScreen.style.display = 'flex';
  sections.forEach(s => s.classList.remove('active'));
  navHomeBtn.classList.remove('visible');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showSection(id) {
  entryScreen.style.display = 'none';
  sections.forEach(s => s.classList.remove('active'));
  const target = document.getElementById(id);
  if (target) {
    target.classList.add('active');
    navHomeBtn.classList.add('visible');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

// Launch buttons on entry screen
document.querySelectorAll('.launch-btn').forEach(btn => {
  btn.addEventListener('click', () => showSection(btn.dataset.target));
});

// Back buttons inside sections
document.querySelectorAll('[data-back]').forEach(btn => {
  btn.addEventListener('click', showEntry);
});

// Top-bar home button + logo
navHomeBtn.addEventListener('click', showEntry);
brandHome.addEventListener('click', (e) => {
  e.preventDefault();
  showEntry();
});

// Footer links
document.querySelectorAll('.footer-links a[data-target]').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    showSection(link.dataset.target);
  });
});

// Paper filter (still works when section is open)
const paperSearch = document.getElementById('paperSearch');
const paperSemester = document.getElementById('paperSemester');
function filterPapers() {
  const query = paperSearch.value.toLowerCase().trim();
  const semester = paperSemester.value;
  document.querySelectorAll('#paperGrid .resource-card').forEach(card => {
    const matchesQuery = card.dataset.search.includes(query) || card.textContent.toLowerCase().includes(query);
    const matchesSemester = !semester || card.dataset.semester === semester;
    card.hidden = !(matchesQuery && matchesSemester);
  });
}
if (paperSearch) paperSearch.addEventListener('input', filterPapers);
if (paperSemester) paperSemester.addEventListener('change', filterPapers);

// Demo form messages
function showDemoMessage(form, messageId, message) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const box = document.getElementById(messageId);
    box.textContent = message;
    box.style.display = 'block';
  });
}
showDemoMessage(
  document.getElementById('accountForm'),
  'accountMessage',
  'Demo only: no account request was sent. Connect a secure backend before using real data.'
);
showDemoMessage(
  document.getElementById('contributionForm'),
  'contributionMessage',
  'Demo only: contribution has not been uploaded. Connect a backend to receive submissions.'
);

// Start on entry screen
showEntry();
