# FAr — Far Western Architecture Students Circle

Static student resource site ready for Cloudflare Pages.

## Files

- `index.html` – main page (entry screen with tappable buttons)
- `styles.css` – all styles
- `app.js` – show/hide sections + filters + demo forms
- `far_logo.png` – logo (add this file)
- `far_front_banner_logo.png` – banner image (add this file)
- Syllabus PDFs (add these files in the same folder)

## Deploy on Cloudflare Pages

1. Add the missing images and PDF files into this folder.
2. Zip the folder **or** push it to a Git repository.
3. In Cloudflare Dashboard → Pages → Create a project → Upload assets (or connect the Git repo).
4. Set the build output directory to the root of this folder (no build step needed).
5. Deploy.

The site works fully as static files — no server required.
